var APP_DATA = {
  "scenes": [
    {
      "id": "0-library-1",
      "name": "Library 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.08396779440399627,
        "pitch": -0.01777815520658166,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": -0.4155793235882186,
          "pitch": 0.26297963516041634,
          "rotation": 0,
          "target": "1-library-2"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.1512499778473,
          "pitch": -0.3439725347922824,
          "title": "CY TOMBLY<br>",
          "text": "<div>Hererrererererererererererer</div><div>ererererererererere</div>"
        }
      ]
    },
    {
      "id": "1-library-2",
      "name": "Library 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.3228252716259874,
        "pitch": -0.0065292404958654515,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": 0.08277436835351537,
          "pitch": 0.16316943343370127,
          "rotation": 0,
          "target": "2-hallway-1"
        },
        {
          "yaw": 3.0476571563249824,
          "pitch": 0.4328691567553662,
          "rotation": 0,
          "target": "0-library-1"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.8680408533608706,
          "pitch": -0.0020541334422237156,
          "title": "Secret Cupboard<br>",
          "text": "<div>FFFFFFFFFFF</div><div>FFFFFFFFFFF<br></div>"
        }
      ]
    },
    {
      "id": "2-hallway-1",
      "name": "Hallway 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.11113656892043622,
        "pitch": -0.004896930371899089,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": 0.10241861764939131,
          "pitch": 0.3708308816325605,
          "rotation": 0,
          "target": "3-hallway-2"
        },
        {
          "yaw": 1.2651335406591162,
          "pitch": 0.5052958769971312,
          "rotation": 0,
          "target": "1-library-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-hallway-2",
      "name": "Hallway 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.12151359653259419,
        "pitch": -0.0032797318596688996,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": -1.4489900797348163,
          "pitch": 0.28256220511181773,
          "rotation": 0,
          "target": "4-hallway-3"
        },
        {
          "yaw": -3.0757533674700976,
          "pitch": 0.33981349636964,
          "rotation": 0,
          "target": "2-hallway-1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-hallway-3",
      "name": "Hallway 3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.23947284493567977,
        "pitch": 0.01632310123966363,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": 0.11043370978076261,
          "pitch": 0.30519236847363373,
          "rotation": 0,
          "target": "5-other-hallway-1"
        },
        {
          "yaw": -2.976724490246445,
          "pitch": 0.4447297400578467,
          "rotation": 0,
          "target": "3-hallway-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-other-hallway-1",
      "name": "Other Hallway 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.22095008344893685,
        "pitch": -0.0032646202479327258,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": 0.10008833822073449,
          "pitch": 0.21078314899517636,
          "rotation": 0,
          "target": "6-other-hallway-2"
        },
        {
          "yaw": -3.010171840522217,
          "pitch": 0.3751617806241043,
          "rotation": 0,
          "target": "4-hallway-3"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6-other-hallway-2",
      "name": "Other Hallway 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.2209500834489404,
        "pitch": -0.02774968356052021,
        "fov": 1.7024994592969018
      },
      "linkHotspots": [
        {
          "yaw": 0.05731473653035479,
          "pitch": 0.2564280185997312,
          "rotation": 0,
          "target": "5-other-hallway-1"
        },
        {
          "yaw": -3.0275409003511182,
          "pitch": 0.2344570064670073,
          "rotation": 0,
          "target": "5-other-hallway-1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
